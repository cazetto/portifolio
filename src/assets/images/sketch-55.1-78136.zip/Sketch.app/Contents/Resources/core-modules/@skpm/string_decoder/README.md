# `string_decoder` for Sketch

All the [nodejs string_decoder](https://nodejs.org/api/string_decoder.html) API is available.

An additional encoding is available: `NSData`, in which case `write` and `end` will return an NSData object.
